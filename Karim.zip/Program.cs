﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OefenProject
{
    /// <summary>
    /// The Program class
    /// </summary>
    static class OefenProject
    {
        /// <summary>
        /// The main method
        /// </summary>
        /// <param name="args"></param>
        static public void Main(String[] args)
        {



            // BEGIN: NIETS AAN DEZE CODE VERANDEREN //
            // Als je code wilt toevoegen aan Main   //
            // doe dat dan hierboven.                //
            Test test = new Test();
            // EINDE: NIETS AAN DEZE CODE VERANDEREN //
        }
    }
}